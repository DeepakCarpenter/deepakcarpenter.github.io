<!DOCTYPE html>
<html>
<head>
<title>TUTORIAL AUTOLIKE</title>
<meta http-equiv="Content-Type" content="text/html;
charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="http://dhedy.jw.lt/css/black/style.css" media="all,handheld"/>
<link href='http://fonts.googleapis.com/css?family=PT+Mono' rel='stylesheet' type='text/css'>
<div class="aut"align="center"><h3>--=[ BACA TUTORIAL DULU BROOTT ]=--</h3></div>
<div class="p_t"align="center">
<b>1. </b>  Pertama umur Facebook kamu, Atau Umur Yg kamu Tulis di Facebook kamu, Harus dibawah 1994 dan seterusnya, Jangan Sampai 1994 ke atas.. Dan setatus viripasi harus publik.
<br/>
<b>2. </b>  Yg kedua Kamu harus punya Pelanggan FB , kalau kamu belum mengaktifkan Klik link ini untuk mengaktifkan &raquo; <a href="http://www.facebook.com/about/subscribe">http://www.facebook.com/about/subscribe</a> <br/> Klik "IZINKAN PELANGGAN" warna hijau ...
<br/><br/>
<b>3. </b>  Sekarang Tinggal AmbiL Token Yg saya sediakan di halaman pertama tadi ,Gett acces token dan insatal klw timbul tulisan sukses lihat Url nya an cpy tuh url lihat dulu screenshootnya .. <br/>
<img src="token.jpg" width="120" height="120" />
<br/><br/>
<b>4. </b>  Kembali ke Halaman Utama, dan PASTE kan URL tadi ke kolom yg sudah saya sediakan, kalau Sudah di Taruh di kolom trsebut, token kaya gini
&raquo; <font color="silver">www.facebook.com/connect/login_success.html#access_token= </font><font color="red"> AAABempp6Ls0BAMjjSCLBkSRmbrzQRk4WlPZBHuEfusKAldATZCm5ZBadukmf1cgZDZD</font>  <font color="silver">&expires_in=0</font><br/>Yang bertanda <b>MERAH</b> itu adalah Code Tokenmu, Yg Lainnya harus dihapus, Hanya yg bertanda MERAHLAH Yg akan kita Submit ... </div></br>
<a href="http://4n4ngcyber.net/like/"> Back To Home</a>
<center>
<div class="aut">&copy; 2012 &mdash; 2013 <br/>
All Right Reserved <br/>
Powered By <a href="http://www.facebook.com/akubaikloh">Kang Mas Anang</a></div></center>
</html>
