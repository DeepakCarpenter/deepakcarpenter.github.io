<!DOCTYPE html>
<html>
<head>
<title>Facebook Autoliker</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="generator" content="PHP SDK v3.0.0" />
<meta name="author" content="Kang Mas Anang" />
<meta name="robots" content="index, follow" />
<meta name="distribution" content="global" />
<meta name="copyright" content="2012" />
<meta name="expires" content="never" />
<link rel="stylesheet" type="text/css" href="http://apmliker.antserve.net/theme/default/style.css" media="all,handheld"/>
<link href='http://fonts.googleapis.com/css?family=PT+Mono'
rel='stylesheet' type='text/css'>
<body>
<link rel="stylesheet" type="text/css" href="http://apmliker.antserve.net/theme/default/style.css" media="all,handheld"/>
</body>
</head>
<center>
<div class="footer"><b>Apm Likers</b></div>
<div class="menu"><b> Autolike Facebook </b></div>
</center>
</br><center>Subscribe Admin</font></center><br/>
<center>
<iframe src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com/widi.grets&layout=box_count&show_faces=false&colorscheme=light&font&width=100&appId=143558975762259" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:60px" allowTransparency="true"></iframe><br/>
</center>
<center>
<div class="menu"><form action="home.php" method="GET">
<font color="black"><b>Access Token :</b></font><br/>
<input type="text" name="accesstoken" class="p_m" style="width:110px"><br><input type="submit" class="aut" value="Submit"></form><br/>
<input type="button" id="get" value="Get Access Token" onClick='window.open("https://www.facebook.com/dialog/permissions.request?app_id=104018109673165&display=wap&next=http://www.facebook.com/connect/login_success.html&response_type=token&perms=email")' /><br/></div></center>
<center>
<a><font color="green">Member</font><font color="green"><div style="text-align:center"><img border="0"src="http://www.webcounter.com/4f9a7591d1dd4/counter.png"/></a><center>
<div class="footer"><center>&copy;2013 Apmlikers&trade; <br/>
All Right Reserved <br/>
Powered By : <a href="http://www.fb.com/widi.grets"><b>Ada Pesan Masuk</a></b></center></div>

</html>
