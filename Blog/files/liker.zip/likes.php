<?php
require 'facebook.php';

$token  = $_GET["accesstoken"];

$host = "localhost";
$username = "anang_wap";
$password = "123456";
$dbname = "anang_wap";

//database connect
mysql_connect($host,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
mysql_query("SET NAMES utf8");

//Create facebook application instance.
$facebook = new Facebook(array(
'appId'  => $fb_app_id,
'secret' => $fb_secret
));

$output = '';







//get users and try liking
$result = mysql_query("
SELECT
*
FROM
phil
");



if($result){
while($row = mysql_fetch_array($result, MYSQL_ASSOC)){
$m = $row['access_token'];
$facebook->setAccessToken ($m);
$id = trim($_POST ['postid']);
try {
$facebook->api("/".$id."/likes", 'POST');
}
catch (FacebookApiException $e) {
$output .= "<p>'". $row['name'] . "' failed to like.</p>";
}
}
}








?>

<title>Auto Like Indonesia</title>
<link rel="shortcut icon" href="http://www.fotogue.net/grimace.png" />
Selamat Anda Telah Menambahkan Jempol banyak..
Jika Ingin Lebih banyak Ajaklah, teman FB mu untuk memakai Autolike ini ... :)
